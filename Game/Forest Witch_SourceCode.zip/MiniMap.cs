﻿using UnityEngine;
using System.Collections;

public class MiniMap : MonoBehaviour {

    public Transform Target;//カメラが向かってるターゲット
    void Start () {
	
	}


    void LateUpdate() {
	}
}
