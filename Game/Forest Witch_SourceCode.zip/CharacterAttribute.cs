﻿using UnityEngine;
using System.Collections;

public class CharacterAttribute : MonoBehaviour {
    public float Radius; //半径
    public float AttackTime;//モンスターが攻撃するタイミング
                           
    void Start () {
	
	}
	void Update () {
	
	}
}
