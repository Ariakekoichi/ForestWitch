﻿using UnityEngine;
using System.Collections;

public class SetBGM : MonoBehaviour {
	public GameObject TitleBGM;
	void Start () {
		
	}
	

	void Update () {
		TitleBGM.SetActive(true);
	}
}
